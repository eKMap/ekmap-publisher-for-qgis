# eKMAP Server Publisher

eKMap Server Publisher for QGIS

## Plugin in QGIS
https://plugins.qgis.org/plugins/eKMap-Publisher-For-QGIS/

## License
[ MIT License ](./LICENSE)

